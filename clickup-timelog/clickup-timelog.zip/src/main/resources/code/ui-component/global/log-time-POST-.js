import * as clickupAPI from 'clickupAPI';

flow
.thenSet("clickUpConfig", a => a.services.data.getRepository("clickupConfig").search( (root, query, cb) => {
			let orgId = a.model.get("organizationEntityId") != null ? a.model.get("organizationEntityId") : -1;
            return cb.or(cb.isNull(root.get("organizationId")), cb.equal(root.get("organizationId"), orgId));
        }).get(0)
    )
.thenSet("clickUpUser", a => a.services.data.getRepository("clickupUser").search( (root, query, cb) => {
			let userId = a.model.get("userEntityId") != null ? a.model.get("userEntityId") : -1;
            return cb.equal(root.get("userId"), userId);
        })
)
.thenSet("ticket", a => a.form.dto.get("ticketId") != null ? a.services.data.getRepository("ticket").findOne(a.form.dto.get("ticketId")) : null)
.then(a => {
	let durationMs = (a.form.dto.get("durationHours") != null ? a.form.dto.get("durationHours") * 3600000 : 0)
    	+ (a.form.dto.get("durationMinutes") != null ? a.form.dto.get("durationMinutes") * 60000 : 0);
	return clickupAPI.postCreateTimeEntry(
        a.model.get("clickUpConfig").apiKey,
        a.model.get("clickUpConfig").teamId,
        durationMs,
        a.form.dto.get("description"),
        a.form.dto.get("date") != null ? (new Date(a.services.util.toString(a.form.dto.get("date")))).getTime() : Date.now().getTime(),
        a.model.get("clickUpUser").length ? a.model.get("clickUpUser").get(0).clickUpUserId : -1,
        a.model.get("ticket") != null ? a.model.get("ticket").clickUpTaskId : '')
})