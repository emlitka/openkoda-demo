flow
.thenSet("TimeEntry", a => a.services.data.getForm("TimeEntry"))
.then(a => a.model.get("TimeEntry").dto.set("userId", a.model.get("userEntityId")))
