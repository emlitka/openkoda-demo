a => a
.manyToOne("userId","user")
.manyToOne("ticketId","ticket")
.date("date")
.number("durationHours")
.number("durationMinutes")
.text("description")