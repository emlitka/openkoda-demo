a => a
.manyToOne("userId","user")
.number("clickUpUserId")