a => a
.manyToOne("userId","user")
.manyToOne("ticketId","ticket")