export function postCreateTimeEntry(apiKey, teamId, duration, description, date, assignee, taskId) {
  let url = `https://api.clickup.com/api/v2/team/${teamId}/time_entries`;
  let timeEntryReq = {
  	duration: duration,
  	description: '[Openkoda Timelog] ' + description,
  	billable: true,
  	start: date,
  	assignee: assignee,
  	tid: taskId,
  };
  let headers = {Authorization: apiKey};
  return context.services.integrations.restPost(url, timeEntryReq, headers);
}