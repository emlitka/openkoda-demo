* init `mvn spring-boot:run -Dspring-boot.run.profiles=openkoda,development,components,drop_and_init_database`
* run `mvn spring-boot:run -Dspring-boot.run.profiles=openkoda,development,components`
* create zip for import `mvn package` 